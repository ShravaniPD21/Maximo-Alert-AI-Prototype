# IBM Maximo Agentic Alert Management - Python Prototype

This is a fully offline, runnable simulation of the alert management
pipeline you designed with your manager. Since you don't have Maximo
suite access yet, this prototype **stands in for** Azure Monitor, the
AI Agent, and the Maximo REST API using plain Python.

## How each file maps to your flowcharts

| File | What it represents |
|---|---|
| `alert_generator.py` | Azure Monitor (sends in sample alerts) |
| `alert_management_layer.py` | "Alert Management layer" box - normalize, assign ID, duplicate check |
| `ai_agent.py` | "AI Agent" box - root cause hint, deduplication, severity scoring/classification |
| `remediation_engine.py` | "AI Agent attempts remediation" box + the UI Pod Failure Handling diagram |
| `mock_maximo_api.py` | Stand-in for the Maximo REST/Integration API - creates SR & WO records |
| `models.py` | The data structure ("shape") of an Alert |
| `config.py` | All the tunable settings (success rates, team assignments, etc.) |
| `main.py` | **Run this file.** Wires everything together and prints the flow step by step |

## Running it

```
python main.py
```

You'll see console output tracing every alert through the exact same
decision points as your flowchart (duplicate check -> AI Agent ->
severity -> remediation attempt -> SR/WO creation -> assignment ->
resolution).

After running, open `maximo_mock_db.json` in the same folder - it will
contain the Service Request and Work Order records exactly as if they'd
been created in real Maximo.

## Extending this later

- **Real Maximo connection**: once you get suite access, only
  `mock_maximo_api.py` needs to change - swap the JSON file read/writes
  for real `requests` calls to Maximo's REST/OSLC endpoints. Nothing else
  in the project needs to change.
- **Real AI reasoning**: `ai_agent.py` has a commented-out example at the
  bottom showing how to swap the rule-based root cause hint for a real
  Claude API call.
- **Real Azure Monitor alerts**: `alert_generator.py` could be replaced
  with a small Flask/FastAPI endpoint that receives Azure Monitor's
  webhook payloads instead of using the hardcoded sample list.
