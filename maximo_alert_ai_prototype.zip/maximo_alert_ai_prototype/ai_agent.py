"""
ai_agent.py
-----------
This is the "AI Agent" box in your flowchart:
  - Root cause hint
  - Deduplication (a second, "fuzzy" check on top of the exact
    resource+type check already done in the Alert Management layer)
  - Severity scoring -> Severity classification (1-4)

NOTE: This is a rule-based ("mock AI") implementation so the whole
prototype runs fully offline with no API keys or internet needed.
See the note at the bottom of this file for how to upgrade the root
cause hint to a real Claude API call later, once you want to show
"real AI reasoning" to your manager.
"""

from difflib import SequenceMatcher
from config import ROOT_CAUSE_KB, SEVERITY_RULES
from models import Alert


class AIAgent:
    def __init__(self, similarity_threshold: float = 0.85):
        self.similarity_threshold = similarity_threshold
        self._seen_descriptions = []  # used by the fuzzy dedup check

    # ---------- Root cause hint ----------
    def root_cause_hint(self, alert: Alert) -> str:
        return ROOT_CAUSE_KB.get(
            alert.alert_type,
            "No known pattern matched - recommend manual investigation."
        )

    # ---------- Deduplication (fuzzy, description-based) ----------
    def is_fuzzy_duplicate(self, alert: Alert) -> bool:
        for seen in self._seen_descriptions:
            ratio = SequenceMatcher(None, seen, alert.description).ratio()
            if ratio >= self.similarity_threshold:
                return True
        self._seen_descriptions.append(alert.description)
        return False

    # ---------- Severity scoring ----------
    def score_severity(self, alert: Alert) -> int:
        """
        Returns an integer 1 (most severe) - 4 (least severe), based on
        the same signals shown in your flowchart: business criticality,
        users impacted, production outage, workaround availability, etc.
        """
        score = 0

        criticality_points = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}
        score += criticality_points.get(alert.business_criticality, 1)

        if alert.users_impacted > 100:
            score += 4
        elif alert.users_impacted > 10:
            score += 2
        elif alert.users_impacted > 0:
            score += 1

        if alert.environment == "Production" and "outage" in alert.description.lower():
            score += 4

        # Purely informational alerts always stay low severity
        if "info" in alert.alert_type.lower():
            score = 1

        if score >= 9:
            return 1
        elif score >= 6:
            return 2
        elif score >= 3:
            return 3
        else:
            return 4

    def classify(self, alert: Alert) -> Alert:
        """Fills in root_cause_hint and severity directly on the alert object."""
        alert.root_cause_hint = self.root_cause_hint(alert)
        severity_num = self.score_severity(alert)
        alert.severity = f"Severity {severity_num} ({SEVERITY_RULES[severity_num]})"
        return alert


# ---------------------------------------------------------------------
# OPTIONAL UPGRADE (do this later, once the offline version works):
# Replace root_cause_hint() with a real Claude API call so the "AI"
# is genuinely reasoning instead of doing a keyword lookup. Example:
#
#   import anthropic
#   client = anthropic.Anthropic(api_key="YOUR_KEY_HERE")
#
#   def root_cause_hint(self, alert):
#       msg = client.messages.create(
#           model="claude-sonnet-4-6",
#           max_tokens=200,
#           messages=[{"role": "user", "content":
#               f"Given this IT infrastructure alert: '{alert.description}', "
#               f"give a one-sentence likely root cause for an IBM Maximo "
#               f"production environment."}]
#       )
#       return msg.content[0].text
#
# This is a good "phase 2" to show once your manager wants to see
# genuine AI reasoning rather than a rules engine.
# ---------------------------------------------------------------------
