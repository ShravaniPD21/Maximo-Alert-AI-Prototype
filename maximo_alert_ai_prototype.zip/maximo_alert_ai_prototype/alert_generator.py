"""
alert_generator.py
-------------------
Stands in for Azure Monitor. In real life, Azure Monitor would push
metric/log/activity-log alerts to your system via a webhook. Here we
just define a realistic sample batch -- including one deliberate
duplicate -- so a single run of the demo exercises every branch of
your flowchart.

Feel free to add more entries to these lists to test other scenarios.
"""

SAMPLE_ALERTS = [
    {
        "alert_type": "DB Connection Failure",
        "resource": "maximo-db-01",
        "description": "Application unable to reach database - connection pool exhausted, production outage.",
        "business_criticality": "Critical",
        "users_impacted": 500,
        "environment": "Production",
    },
    {
        # Deliberate duplicate of the DB alert above. DB Connection Failure has
        # a low auto-remediation success rate, so the original alert is still
        # "open" when this duplicate arrives -> this reliably triggers the
        # "Duplicate of an already open alert?" branch when run with the
        # random seed set in main.py.
        "alert_type": "DB Connection Failure",
        "resource": "maximo-db-01",
        "description": "Application unable to reach database - connection pool exhausted, production outage.",
        "business_criticality": "Critical",
        "users_impacted": 500,
        "environment": "Production",
    },
    {
        "alert_type": "High CPU",
        "resource": "maximo-app-server-01",
        "description": "CPU usage above 95% for 10 minutes on production app server.",
        "metric_value": 96.4,
        "business_criticality": "High",
        "users_impacted": 40,
        "environment": "Production",
    },
    {
        "alert_type": "Disk Space Low",
        "resource": "maximo-file-server-02",
        "description": "Disk usage above 90%, workaround available (manual log purge).",
        "business_criticality": "Medium",
        "users_impacted": 5,
        "environment": "Production",
    },
    {
        "alert_type": "Info Alert",
        "resource": "maximo-batch-job-07",
        "description": "Scheduled nightly batch job completed with informational notice.",
        "business_criticality": "Low",
        "users_impacted": 0,
        "environment": "Production",
    },
]

# Handled by the separate "UI Pod Failure Handling via OpenShift" path in main.py
UI_POD_ALERTS = [
    {
        "alert_type": "UI Pod Down",
        "resource": "maximo-ui-pod-3",
        "description": "OpenShift health check failed for maximo-ui-pod-3.",
        "business_criticality": "High",
        "users_impacted": 0,
        "environment": "Production",
        "other_pods_running": True,   # -> "Yes" branch: traffic redirected
    },
    {
        "alert_type": "UI Pod Down",
        "resource": "maximo-ui-pod-all",
        "description": "All OpenShift UI pod replicas failed health checks simultaneously.",
        "business_criticality": "Critical",
        "users_impacted": 800,
        "environment": "Production",
        "other_pods_running": False,  # -> "No" branch: full outage
    },
]
