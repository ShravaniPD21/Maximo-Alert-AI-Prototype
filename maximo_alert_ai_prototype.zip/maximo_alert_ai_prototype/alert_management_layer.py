"""
alert_management_layer.py
--------------------------
This is the "Alert Management layer" box in your flowchart:
  - Normalizes raw alerts coming in from Azure Monitor
  - Assigns each alert a unique Alert ID
  - Checks whether the alert is a duplicate of one already open
"""

import itertools
from datetime import datetime
from models import Alert


class AlertManagementLayer:
    def __init__(self):
        # Simulates the "currently open alerts" store.
        # Key = (resource, alert_type) -> Value = Alert object
        self.open_alerts = {}
        self._id_counter = itertools.count(1)

    def _generate_alert_id(self):
        return f"ALT-{next(self._id_counter):05d}"

    def normalize(self, raw_alert: dict) -> Alert:
        """Turn a raw dict (as if it came straight from Azure Monitor) into a clean Alert object."""
        return Alert(
            alert_id=self._generate_alert_id(),
            source=raw_alert.get("source", "Azure Monitor"),
            alert_type=raw_alert["alert_type"],
            resource=raw_alert["resource"],
            description=raw_alert.get("description", ""),
            raw_metric_value=raw_alert.get("metric_value"),
            business_criticality=raw_alert.get("business_criticality", "Low"),
            users_impacted=raw_alert.get("users_impacted", 0),
            environment=raw_alert.get("environment", "Production"),
            timestamp=datetime.now(),
        )

    def check_duplicate(self, alert: Alert):
        """
        If this alert matches one already open (same resource + alert type),
        bump its occurrence count and return the EXISTING alert.
        Otherwise register this as a newly open alert and return None.
        """
        key = (alert.resource, alert.alert_type)
        existing = self.open_alerts.get(key)

        if existing is not None:
            existing.occurrence_count += 1
            existing.timestamp = datetime.now()
            return existing

        self.open_alerts[key] = alert
        return None

    def close_alert(self, alert: Alert):
        key = (alert.resource, alert.alert_type)
        self.open_alerts.pop(key, None)
