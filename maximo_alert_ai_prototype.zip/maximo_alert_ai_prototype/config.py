"""
config.py
---------
All the "tuning knobs" of our prototype live here, so you can change
behavior later without hunting through every file.
"""

# Chance (0.0 - 1.0) that an automated remediation attempt succeeds,
# per alert type. This simulates real-world automation success rates.
REMEDIATION_SUCCESS_RATES = {
    "High CPU": 0.7,
    "Service Unresponsive": 0.6,
    "DB Connection Failure": 0.4,
    "Disk Space Low": 0.8,
    "Memory Leak": 0.3,
    "default": 0.5,
}

# Which team a Work Order should be assigned to, based on alert type
RESOLVER_TEAM_MAPPING = {
    "High CPU": "Infra Team",
    "Service Unresponsive": "App Support Team",
    "DB Connection Failure": "DBA Team",
    "Disk Space Low": "Infra Team",
    "Memory Leak": "App Support Team",
    "UI Pod Down": "OpenShift/Platform Team",
    "default": "L1 Support Team",
}

# Simple keyword -> root cause hint "knowledge base".
# In a real system this would be replaced by an LLM call or a trained model
# (see the note at the bottom of ai_agent.py for how to do that later).
ROOT_CAUSE_KB = {
    "High CPU": "Possible runaway process or insufficient compute sizing.",
    "Service Unresponsive": "Service may be hung, deadlocked, or overloaded with requests.",
    "DB Connection Failure": "Database may be down, connection pool exhausted, or a network issue between app and DB.",
    "Disk Space Low": "Log files or temp data may not be getting purged/rotated.",
    "Memory Leak": "Application may not be releasing memory correctly over time.",
    "UI Pod Down": "One or more OpenShift pod replicas has failed health checks.",
}

# Labels shown for each severity level (used in printed output and SR/WO records)
SEVERITY_RULES = {
    1: "Critical - Immediate Action",
    2: "High - Urgent, Elevated",
    3: "Medium - Standard Priority",
    4: "Low - Routine Priority",
}
