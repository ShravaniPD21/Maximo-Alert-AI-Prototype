"""
main.py
--------
THIS IS THE FILE YOU RUN.

It wires every module together to replay your full flowchart, end-to-end,
across a batch of simulated alerts:

  Azure Monitor -> Alert Management layer -> duplicate? update SR
      -> AI Agent (root cause hint / severity scoring) -> Severity classification
      -> AI Agent attempts remediation -> success? auto-close
      -> fail? Maximo REST: create SR -> create WO -> assign -> resolve

Plus a separate path for the "UI Pod Failure Handling via OpenShift" diagram.

Run it with:   python main.py
"""

import random

from alert_management_layer import AlertManagementLayer
from ai_agent import AIAgent
from remediation_engine import RemediationEngine
from mock_maximo_api import MockMaximoAPI
from alert_generator import SAMPLE_ALERTS, UI_POD_ALERTS

# A fixed random "seed" makes the remediation success/failure simulation
# reproducible -- you'll see the exact same pipeline outcome every time
# you run this file. Remove this line (or change the number) if you want
# a different, randomized outcome each run.
random.seed(42)


def line(char="-", width=72):
    print(char * width)


def process_standard_alert(raw_alert, mgmt, agent, remediator, maximo):
    line("=")
    alert = mgmt.normalize(raw_alert)
    print(f"[Azure Monitor]       New alert for resource '{alert.resource}'")
    print(f"[Alert Mgmt Layer]    Normalized. Assigned Alert ID: {alert.alert_id}")

    duplicate_of = mgmt.check_duplicate(alert)
    if duplicate_of is not None:
        print(f"[Alert Mgmt Layer]    DUPLICATE of {duplicate_of.alert_id} "
              f"-> occurrence_count now {duplicate_of.occurrence_count}")
        sr_id = maximo.find_sr_for_alert(alert)
        if sr_id:
            maximo.update_sr_duplicate(sr_id, duplicate_of.occurrence_count)
            print(f"[Maximo API]          Updated {sr_id}: occurrence++, last_updated_date refreshed")
        else:
            print("[Maximo API]          No SR exists yet for this resource (original still processing).")
        return

    print("[Alert Mgmt Layer]    Not a duplicate -> continuing to AI Agent analysis")

    agent.classify(alert)
    print(f"[AI Agent]            Root cause hint: {alert.root_cause_hint}")
    print(f"[AI Agent]            Severity classification: {alert.severity}")

    print("[AI Agent]            Attempting automated remediation "
          "(restart service / clear cache / reconnect DB / scale resources)...")
    success = remediator.attempt_generic_remediation(alert)

    if success:
        alert.status = "Auto-Closed"
        mgmt.close_alert(alert)
        print("[AI Agent]            Remediation SUCCESSFUL -> alert auto-closed. No SR/WO needed.")
    else:
        alert.status = "Escalated"
        print("[AI Agent]            Remediation FAILED -> creating Service Request automatically.")
        sr_id = maximo.create_sr(alert)
        print(f"[Maximo API]          Service Request created: {sr_id} (status: NEW)")
        wo_id, team = maximo.create_wo(sr_id, alert)
        print(f"[Maximo API]          Work Order created: {wo_id}, priority={alert.severity}, "
              f"assigned to: {team}")
        maximo.close_wo(wo_id)  # simulate the team resolving it, for demo purposes
        print(f"[Maximo API]          Work completed by {team} -> {wo_id} CLOSED")


def process_ui_pod_alert(raw_alert, mgmt, remediator, maximo):
    line("=")
    alert = mgmt.normalize(raw_alert)
    print(f"[OpenShift]           Pod health check failed for '{alert.resource}'")
    print(f"[Alert Mgmt Layer]    Assigned Alert ID: {alert.alert_id}")

    other_pods_running = raw_alert["other_pods_running"]
    result = remediator.handle_ui_pod_failure(alert, other_pods_running)
    alert.severity = result["severity_label"]

    print(f"[AI Agent]            {result['message']}")
    print(f"[AI Agent]            Severity classification: {alert.severity}")

    if result["remediated"]:
        alert.status = "Auto-Resolved"
        print("[AI Agent]            Pod restarted automatically. No SR/WO needed.")
    else:
        alert.status = "Escalated"
        sr_id = maximo.create_sr(alert)
        wo_id, team = maximo.create_wo(sr_id, alert)
        print(f"[Maximo API]          {sr_id} and {wo_id} created, assigned to: {team}")
        print("[Notification]        Email alert sent to the support group.")


def main():
    mgmt = AlertManagementLayer()
    agent = AIAgent()
    remediator = RemediationEngine()
    maximo = MockMaximoAPI()

    print("Starting IBM Maximo Agentic Alert Management Pipeline (PROTOTYPE)")
    print("Simulating alerts as if they came in live from Azure Monitor...\n")

    for raw_alert in SAMPLE_ALERTS:
        process_standard_alert(raw_alert, mgmt, agent, remediator, maximo)

    for raw_alert in UI_POD_ALERTS:
        process_ui_pod_alert(raw_alert, mgmt, remediator, maximo)

    line("=")
    print("\nPipeline run complete.")
    print("All Service Request / Work Order records created during this run "
          "were written to maximo_mock_db.json - open that file to inspect them.")


if __name__ == "__main__":
    main()
