"""
mock_maximo_api.py
-------------------
Stands in for the real IBM Maximo REST/Integration API, since you don't
have suite access right now. It stores Service Requests (SR) and Work
Orders (WO) in a local JSON file (maximo_mock_db.json), so after running
the demo you can literally open that file and see records shaped the
way Maximo would hold them -- just simplified.

When you eventually get Maximo access, you would replace the methods in
this file with real HTTP calls (using the `requests` library) to Maximo's
OSLC/REST endpoints -- everything else in the project (alert_management_layer.py,
ai_agent.py, remediation_engine.py, main.py) stays exactly the same,
because they only ever talk to THIS file, never to Maximo directly.
That's the whole point of keeping this as a separate module.
"""

import json
import os
import itertools
from datetime import datetime
from config import RESOLVER_TEAM_MAPPING

DB_FILE = os.path.join(os.path.dirname(__file__), "maximo_mock_db.json")


class MockMaximoAPI:
    def __init__(self):
        self._sr_counter = itertools.count(1)
        self._wo_counter = itertools.count(1)
        self.db = {"service_requests": {}, "work_orders": {}}
        self._load()

    # ---------- persistence ----------
    def _load(self):
        if os.path.exists(DB_FILE):
            with open(DB_FILE, "r") as f:
                self.db = json.load(f)
            existing_sr = [int(k.split("-")[1]) for k in self.db["service_requests"]]
            existing_wo = [int(k.split("-")[1]) for k in self.db["work_orders"]]
            self._sr_counter = itertools.count(max(existing_sr, default=0) + 1)
            self._wo_counter = itertools.count(max(existing_wo, default=0) + 1)

    def _save(self):
        with open(DB_FILE, "w") as f:
            json.dump(self.db, f, indent=2, default=str)

    # ---------- Service Requests ----------
    def create_sr(self, alert):
        sr_id = f"SR-{next(self._sr_counter):05d}"
        record = {
            "sr_id": sr_id,
            "status": "NEW",
            "alert_id": alert.alert_id,
            "resource": alert.resource,
            "description": alert.description,
            "severity": alert.severity,
            "root_cause_hint": alert.root_cause_hint,
            "occurrence_count": alert.occurrence_count,
            "created_on": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
        }
        self.db["service_requests"][sr_id] = record
        self._save()
        return sr_id

    def update_sr_duplicate(self, sr_id, occurrence_count):
        record = self.db["service_requests"].get(sr_id)
        if record:
            record["occurrence_count"] = occurrence_count
            record["last_updated"] = datetime.now().isoformat()
            self._save()

    def find_sr_for_alert(self, alert):
        """Look up an existing open SR tied to a duplicate alert's resource."""
        for sr_id, record in self.db["service_requests"].items():
            if record["resource"] == alert.resource and record["status"] != "CLOSED":
                return sr_id
        return None

    # ---------- Work Orders ----------
    def create_wo(self, sr_id, alert):
        wo_id = f"WO-{next(self._wo_counter):05d}"
        team = RESOLVER_TEAM_MAPPING.get(alert.alert_type, RESOLVER_TEAM_MAPPING["default"])
        record = {
            "wo_id": wo_id,
            "sr_id": sr_id,
            "status": "OPEN",
            "priority": alert.severity,
            "assigned_team": team,
            "created_on": datetime.now().isoformat(),
        }
        self.db["work_orders"][wo_id] = record
        self._save()
        return wo_id, team

    def close_wo(self, wo_id):
        record = self.db["work_orders"].get(wo_id)
        if record:
            record["status"] = "CLOSED"
            record["closed_on"] = datetime.now().isoformat()
            self._save()
