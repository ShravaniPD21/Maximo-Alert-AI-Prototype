"""
models.py
---------
Defines the shape of an "Alert" as it flows through the pipeline.

We use a Python @dataclass here -- think of it as a template/blueprint
for what information every alert must carry. Python will auto-generate
the boring boilerplate code for us.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Alert:
    alert_id: str
    source: str
    alert_type: str            # e.g. "High CPU", "DB Connection Failure"
    resource: str               # e.g. "maximo-app-server-01"
    description: str
    raw_metric_value: Optional[float] = None
    business_criticality: str = "Low"     # Critical / High / Medium / Low
    users_impacted: int = 0
    environment: str = "Production"
    timestamp: datetime = field(default_factory=datetime.now)

    # Fields that get filled in as the alert moves through the pipeline
    severity: Optional[str] = None
    root_cause_hint: Optional[str] = None
    occurrence_count: int = 1
    status: str = "New"
