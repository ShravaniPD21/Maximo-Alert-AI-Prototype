"""
remediation_engine.py
----------------------
This is the "AI Agent attempts remediation" box, plus the special
"UI Pod Failure Handling via OpenShift" scenario from your 4th diagram.
"""

import random
from config import REMEDIATION_SUCCESS_RATES
from models import Alert


class RemediationEngine:
    def attempt_generic_remediation(self, alert: Alert) -> bool:
        """
        Simulates trying an automated fix: restart service, clear cache,
        reconnect database, scale cloud resources, etc.
        Returns True if the fix "worked", False otherwise.

        We use random.random() here to simulate real-world uncertainty --
        an automated fix doesn't always work. success_rate controls how
        likely it is to succeed for each alert type (see config.py).
        """
        success_rate = REMEDIATION_SUCCESS_RATES.get(
            alert.alert_type, REMEDIATION_SUCCESS_RATES["default"]
        )
        return random.random() < success_rate

    def handle_ui_pod_failure(self, alert: Alert, other_pods_running: bool) -> dict:
        """
        Mirrors your 'UI Pod Failure Handling via OpenShift' diagram exactly.
        Returns a dict describing what happened, since this path has its
        own dedicated severity + messaging logic (separate from the
        generic remediation path above).
        """
        if other_pods_running:
            return {
                "remediated": True,
                "severity_num": 3,
                "severity_label": "Severity: Medium (No impact to users)",
                "message": (
                    "Traffic redirected automatically to remaining pods. "
                    "AI Agent restarted the failed pod copy. "
                    "No human intervention needed."
                ),
            }
        else:
            return {
                "remediated": False,
                "severity_num": 1,
                "severity_label": "Severity: Critical (Escalated immediately)",
                "message": (
                    "No working pod copies remain -> full service outage. "
                    "AI Agent attempted a fix immediately without waiting for "
                    "approval, because speed matters here. Email alert sent "
                    "to the support group."
                ),
            }
